Use the Train-Random-Forest-Regressor-Save2CSV.py to train the network
Took about 30 min - 1 hour

Exports the test data along with the predictions into a CSV

Trained model was ~1.7GB 

Link to Trained Model Shared folder: https://turfptax-my.sharepoint.com/:f:/p/mde/EkM4ak0Q3KFPpRHp2MSWp1wBbA-oGd9gcwdz4Dc1zvTZ7Q?e=SaytKZ

Model creates the same output as data shown in images on or before 3-27-2023

-TURFPTAx


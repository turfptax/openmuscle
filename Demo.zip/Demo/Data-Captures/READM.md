# Capture Set With 3 separate files
capture_08.txt
capture_09.txt
capture_10.txt

# Best Capture January23
Also named datasetONE.txt in some cases. 

# Filter Data & Convert to CSV
sensor_data_filter.py is used to match LASK and Open Muscle Packets.

It also converts the file into CSV format for machine learning.

